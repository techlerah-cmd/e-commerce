import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { addAdminProduct } from "@/lib/adminStore";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const AddProduct = () => {
  const [form, setForm] = useState({
    name: "",
    price: "",
    originalPrice: "",
    image: "",
    isNew: false,
    description: "",
    fabric: "",
    work: "",
    occasion: "",
    careInstructions: "",
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseInt(form.price || "0", 10);
    const originalPrice = form.originalPrice ? parseInt(form.originalPrice, 10) : undefined;
    if (!form.name || !price || !form.image) {
      toast({ title: "Missing fields", description: "Name, price and image are required." });
      return;
    }
    const created = addAdminProduct({
      name: form.name,
      price,
      originalPrice,
      image: form.image,
      isNew: form.isNew,
      description: form.description,
      fabric: form.fabric,
      work: form.work,
      occasion: form.occasion,
      careInstructions: form.careInstructions,
    } as any);
    toast({ title: "Product added", description: `${created.name} has been added.` });
    navigate(`/product/${created.id}`);
  };

  return (
    <AdminLayout>
      <div className="max-w-3xl">
        <h1 className="font-serif-elegant text-3xl text-primary mb-6">Add Product</h1>
        <Card>
          <CardHeader>
            <CardTitle className="font-serif-elegant text-xl text-primary">Product Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleSubmit}>
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="price">Price (₹)</Label>
                      <Input id="price" type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} required />
                    </div>
                    <div>
                      <Label htmlFor="originalPrice">Original Price (₹)</Label>
                      <Input id="originalPrice" type="number" value={form.originalPrice} onChange={e => setForm({ ...form, originalPrice: e.target.value })} />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="image">Image URL</Label>
                    <Input id="image" value={form.image} onChange={e => setForm({ ...form, image: e.target.value })} required />
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="isNew" checked={form.isNew} onCheckedChange={(v) => setForm({ ...form, isNew: Boolean(v) })} />
                    <Label htmlFor="isNew">Mark as New</Label>
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" rows={4} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="fabric">Fabric</Label>
                      <Input id="fabric" value={form.fabric} onChange={e => setForm({ ...form, fabric: e.target.value })} />
                    </div>
                    <div>
                      <Label htmlFor="work">Work</Label>
                      <Input id="work" value={form.work} onChange={e => setForm({ ...form, work: e.target.value })} />
                    </div>
                    <div>
                      <Label htmlFor="occasion">Occasion</Label>
                      <Input id="occasion" value={form.occasion} onChange={e => setForm({ ...form, occasion: e.target.value })} />
                    </div>
                    <div>
                      <Label htmlFor="care">Care Instructions</Label>
                      <Input id="care" value={form.careInstructions} onChange={e => setForm({ ...form, careInstructions: e.target.value })} />
                    </div>
                  </div>
                  <div className="pt-2">
                    <Button type="submit" className="btn-luxury">Save Product</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
    </AdminLayout>
  );
};

export default AddProduct;
