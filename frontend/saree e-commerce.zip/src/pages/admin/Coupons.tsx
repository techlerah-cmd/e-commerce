import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useEffect, useState } from "react";
import { Coupon, addCoupon, getCoupons, saveCoupons } from "@/lib/adminStore";
import { useToast } from "@/hooks/use-toast";

const Coupons = () => {
  const [list, setList] = useState<Coupon[]>([]);
  const [form, setForm] = useState({ code: "", description: "", discountType: "percent" as Coupon["discountType"], amount: "", active: true });
  const { toast } = useToast();

  useEffect(() => {
    setList(getCoupons());
  }, []);

  const refresh = () => setList(getCoupons());

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.code || !form.amount) {
      toast({ title: "Missing fields", description: "Code and amount are required." });
      return;
    }
    const amount = parseInt(form.amount, 10) || 0;
    addCoupon({ code: form.code.trim(), description: form.description, discountType: form.discountType, amount, active: form.active });
    setForm({ code: "", description: "", discountType: "percent", amount: "", active: true });
    refresh();
    toast({ title: "Coupon saved" });
  };

  const toggleActive = (code: string) => {
    const next = list.map(c => c.code === code ? { ...c, active: !c.active } : c);
    saveCoupons(next);
    setList(next);
  };

  return (
    <AdminLayout>
      <div className="max-w-4xl space-y-8">
        <h1 className="font-serif-elegant text-3xl text-primary">Manage Coupons</h1>

        <Card>
          <CardHeader>
            <CardTitle className="font-serif-elegant text-xl text-primary">Add Coupon</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="grid grid-cols-1 gap-4 sm:grid-cols-2" onSubmit={handleAdd}>
                  <div>
                    <Label htmlFor="code">Code</Label>
                    <Input id="code" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} required />
                  </div>
                  <div>
                    <Label htmlFor="amount">Amount</Label>
                    <Input id="amount" type="number" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required />
                  </div>
                  <div>
                    <Label>Type</Label>
                    <div className="flex gap-3">
                      <Button type="button" variant={form.discountType === "percent" ? "default" : "outline"} onClick={() => setForm({ ...form, discountType: "percent" })}>Percent</Button>
                      <Button type="button" variant={form.discountType === "flat" ? "default" : "outline"} onClick={() => setForm({ ...form, discountType: "flat" })}>Flat (₹)</Button>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="active">Active</Label>
                    <div className="mt-2">
                      <Switch id="active" checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: Boolean(v) })} />
                    </div>
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="description">Description</Label>
                    <Input id="description" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
                  </div>
                  <div className="sm:col-span-2">
                    <Button type="submit" className="btn-luxury">Save Coupon</Button>
                  </div>
                </form>
              </CardContent>
            </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-serif-elegant text-xl text-primary">Existing Coupons</CardTitle>
          </CardHeader>
          <CardContent>
            {list.length === 0 ? (
              <p className="text-muted-foreground">No coupons yet.</p>
            ) : (
              <div className="space-y-3">
                {list.map(c => (
                  <div key={c.code} className="flex items-center justify-between rounded-md bg-white p-4">
                    <div>
                      <p className="font-medium text-primary">{c.code} {c.active ? '' : '(inactive)'}</p>
                      <p className="text-xs text-muted-foreground">{c.discountType === 'percent' ? `${c.amount}%` : `₹${c.amount}`} {c.description ? `• ${c.description}` : ''}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Switch checked={c.active} onCheckedChange={() => toggleActive(c.code)} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

      </div>
    </AdminLayout>
  );
};

export default Coupons;
