import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const AdminDashboard = () => {
  return (
    <AdminLayout>
      <div className="space-y-8">
        <h1 className="font-serif-elegant text-3xl text-primary">Admin Dashboard</h1>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="font-serif-elegant text-xl text-primary">Products</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">Add or manage products.</p>
              <div className="flex gap-3">
                <Link to="/admin/products/new"><Button className="btn-luxury">Add Product</Button></Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="font-serif-elegant text-xl text-primary">Coupons</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">Create and manage coupons.</p>
              <div>
                <Link to="/admin/coupons"><Button variant="outline" className="btn-outline-luxury">Manage Coupons</Button></Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="font-serif-elegant text-xl text-primary">Orders</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">View submitted orders.</p>
              <div>
                <Link to="/admin/orders"><Button variant="outline" className="btn-outline-luxury">View Orders</Button></Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;
