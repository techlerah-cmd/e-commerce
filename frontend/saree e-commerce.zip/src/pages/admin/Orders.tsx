import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { getOrders } from "@/lib/adminStore";
import { useEffect, useState } from "react";

const Orders = () => {
  const [orders, setOrders] = useState(() => getOrders());

  useEffect(() => {
    setOrders(getOrders());
  }, []);

  return (
    <AdminLayout>
      <div className="max-w-6xl space-y-8">
        <h1 className="font-serif-elegant text-3xl text-primary">Orders</h1>

        {orders.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">No orders yet.</CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {orders.map((o) => (
              <Card key={o.id}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-primary">
                    <span>Order #{o.id.slice(0, 8).toUpperCase()}</span>
                    <span className="text-sm text-muted-foreground">{new Date(o.createdAt).toLocaleString()}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {o.items.map((i) => (
                      <div key={i.productId} className="flex items-center gap-3">
                        <img src={i.image} alt={i.name} className="h-12 w-10 rounded object-cover" />
                        <div className="flex-1">
                          <p className="font-medium text-primary">{i.name}</p>
                          <p className="text-xs text-muted-foreground">Qty: {i.quantity}</p>
                        </div>
                        <div className="text-sm font-semibold">₹{(i.price * i.quantity).toLocaleString("en-IN")}</div>
                      </div>
                    ))}
                    <Separator />
                    <div className="flex justify-end gap-6 text-sm">
                      <div>Subtotal: <span className="font-medium">₹{o.subtotal.toLocaleString("en-IN")}</span></div>
                      <div>Shipping: <span className="font-medium">{o.shipping === 0 ? "Free" : `₹${o.shipping.toLocaleString("en-IN")}`}</span></div>
                      <div>Discount: <span className="font-medium">₹{o.discount.toLocaleString("en-IN")}{o.couponCode ? ` (${o.couponCode})` : ''}</span></div>
                      <div>Total: <span className="font-semibold text-accent">₹{o.total.toLocaleString("en-IN")}</span></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default Orders;
