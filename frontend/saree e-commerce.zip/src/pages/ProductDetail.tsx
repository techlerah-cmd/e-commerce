import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { getProductById, formatPrice } from "@/data/products";
import { ArrowLeft, Heart, Share2, ShoppingBag, Star, Truck, Shield, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { addToCart } from "@/lib/cart";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedImage, setSelectedImage] = useState(0);
  const [isWishlisted, setIsWishlisted] = useState(false);

  const product = id ? getProductById(parseInt(id)) : null;

  if (!product) {
    return (
      <>
        <Header />
        <main className="min-h-screen bg-secondary flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-serif-elegant text-4xl text-primary mb-4">Product Not Found</h1>
            <p className="text-muted-foreground mb-6">The product you're looking for doesn't exist.</p>
            <Button onClick={() => navigate("/collections")} className="btn-luxury">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Collections
            </Button>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, 1);
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    toast({
      title: isWishlisted ? "Removed from Wishlist" : "Added to Wishlist",
      description: `${product.name} has been ${isWishlisted ? "removed from" : "added to"} your wishlist.`,
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `Check out this beautiful saree: ${product.name}`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Product link has been copied to clipboard.",
      });
    }
  };

  const images = product.additionalImages || [product.image];

  return (
    <>
      <Header />
      <main className="min-h-screen bg-secondary">
        {/* Breadcrumb */}
        <section className="border-b bg-white/70 backdrop-blur supports-[backdrop-filter]:bg-white/60">
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbLink href="/collections">Collections</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>{product.name}</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        {/* Product Details */}
        <section className="px-4 py-12 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
              {/* Product Images */}
              <div className="space-y-4">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-white">
                  <img
                    src={images[selectedImage]}
                    alt={product.name}
                    className="h-full w-full object-cover"
                  />
                  {product.isNew && (
                    <Badge className="absolute left-4 top-4 bg-accent text-accent-foreground">
                      NEW
                    </Badge>
                  )}
                </div>
                {images.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto">
                    {images.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedImage(index)}
                        className={`flex-shrink-0 aspect-square w-20 rounded-md overflow-hidden border-2 transition-colors ${
                          selectedImage === index ? "border-accent" : "border-transparent"
                        }`}
                      >
                        <img
                          src={image}
                          alt={`${product.name} ${index + 1}`}
                          className="h-full w-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="space-y-6">
                <div>
                  <h1 className="font-serif-elegant text-3xl font-bold text-primary lg:text-4xl">
                    {product.name}
                  </h1>
                  <div className="mt-3 flex items-center gap-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">(4.8) • 127 reviews</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="font-sans-clean text-3xl font-bold text-accent">
                    {formatPrice(product.price)}
                  </span>
                  {product.originalPrice && (
                    <span className="font-sans-clean text-xl text-muted-foreground line-through">
                      {formatPrice(product.originalPrice)}
                    </span>
                  )}
                  {product.originalPrice && (
                    <Badge variant="destructive" className="text-xs">
                      {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                    </Badge>
                  )}
                </div>

                <p className="font-sans-clean text-muted-foreground leading-relaxed">
                  {product.description}
                </p>

                {/* Product Specifications */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-serif-elegant text-lg font-semibold text-primary mb-4">
                      Product Details
                    </h3>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Fabric:</span>
                        <span className="font-medium">{product.fabric}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Work:</span>
                        <span className="font-medium">{product.work}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Saree Length:</span>
                        <span className="font-medium">{product.specifications?.sareeLength}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Blouse:</span>
                        <span className="font-medium">{product.specifications?.blouse}</span>
                      </div>
                      <div className="flex justify-between col-span-full">
                        <span className="text-muted-foreground">Occasion:</span>
                        <span className="font-medium">{product.occasion}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <Button onClick={handleAddToCart} className="btn-luxury flex-1">
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      Add to Cart
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleWishlist}
                      className={`btn-outline-luxury ${isWishlisted ? "bg-red-50 border-red-200" : ""}`}
                    >
                      <Heart className={`h-4 w-4 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
                    </Button>
                    <Button variant="outline" onClick={handleShare} className="btn-outline-luxury">
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button
                    variant="outline"
                    className="btn-outline-luxury w-full"
                    onClick={() => {
                      addToCart(product, 1);
                      navigate("/cart");
                    }}
                  >
                    Buy Now
                  </Button>
                </div>

                {/* Features */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div className="flex items-center gap-3 rounded-lg bg-white/50 p-4">
                    <Truck className="h-5 w-5 text-accent" />
                    <div>
                      <p className="font-medium text-sm">Free Shipping</p>
                      <p className="text-xs text-muted-foreground">On orders above ₹2000</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 rounded-lg bg-white/50 p-4">
                    <RotateCcw className="h-5 w-5 text-accent" />
                    <div>
                      <p className="font-medium text-sm">Easy Returns</p>
                      <p className="text-xs text-muted-foreground">7 days return policy</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 rounded-lg bg-white/50 p-4">
                    <Shield className="h-5 w-5 text-accent" />
                    <div>
                      <p className="font-medium text-sm">Authentic</p>
                      <p className="text-xs text-muted-foreground">100% genuine products</p>
                    </div>
                  </div>
                </div>

                {/* Care Instructions */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-serif-elegant text-lg font-semibold text-primary mb-3">
                      Care Instructions
                    </h3>
                    <p className="font-sans-clean text-muted-foreground text-sm leading-relaxed">
                      {product.careInstructions}
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </main>
    </>
  );
};

export default ProductDetail;
