import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useEffect, useState } from "react";
import { CartItem, clearCart, getCart, getCartTotals, removeFromCart, updateQuantity } from "@/lib/cart";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { applyCoupon } from "@/lib/adminStore";
import { useToast } from "@/hooks/use-toast";
import { beginCheckoutFromCart, setCheckoutState } from "@/lib/checkout";

const Cart = () => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [coupon, setCoupon] = useState("");
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [appliedCode, setAppliedCode] = useState<string | undefined>(undefined);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    setItems(getCart());
  }, []);

  const refresh = () => setItems(getCart());

  const { subtotal, shipping, formatPrice } = getCartTotals(items);
  const total = Math.max(0, subtotal - appliedDiscount) + shipping;

  const isEmpty = items.length === 0;

  return (
    <>
      <Header />
      <main className="min-h-screen bg-secondary">
        <section className="border-b bg-white/70 backdrop-blur supports-[backdrop-filter]:bg-white/60">
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>Cart</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </section>

        <section className="px-3 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-4">
              <h1 className="font-serif-elegant text-3xl text-primary">Your Cart</h1>

              {isEmpty ? (
                <Card>
                  <CardContent className="py-16 text-center">
                    <ShoppingBag className="mx-auto mb-4 h-10 w-10 text-muted-foreground" />
                    <p className="text-muted-foreground">Your cart is empty</p>
                    <Button className="btn-luxury mt-6" onClick={() => navigate("/collections")}>Explore Collections</Button>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-purple-200">
                  <CardContent className="p-0 divide-y">
                    {items.map((item) => (
                      <div key={item.productId} className="flex items-center gap-4 p-4">
                        <img src={item.image} alt={item.name} className="h-20 w-16 rounded-md object-cover ring-1 ring-purple-200" />
                        <div className="flex-1">
                          <p className="font-medium text-primary">{item.name}</p>
                          <p className="text-sm text-muted-foreground">{formatPrice(item.price)}</p>
                          <div className="mt-3 flex items-center gap-2">
                            <Button variant="outline" size="icon" className="h-8 w-8 border-purple-300 text-purple-700 hover:bg-purple-50" onClick={() => { updateQuantity(item.productId, item.quantity - 1); refresh(); }}>
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <Button variant="outline" size="icon" className="h-8 w-8 border-purple-300 text-purple-700 hover:bg-purple-50" onClick={() => { updateQuantity(item.productId, item.quantity + 1); refresh(); }}>
                              <Plus className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="ml-2 hover:bg-amber-50" onClick={() => { removeFromCart(item.productId); refresh(); }}>
                              <Trash2 className="h-4 w-4 text-amber-600" />
                            </Button>
                          </div>
                        </div>
                        <div className="text-right font-semibold text-accent min-w-24">
                          {formatPrice(item.price * item.quantity)}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {!isEmpty && (
                <div className="flex justify-between">
                  <Button variant="outline" className="border-amber-300 text-amber-700 hover:bg-amber-50" onClick={() => { clearCart(); refresh(); }}>
                    Clear Cart
                  </Button>
                </div>
              )}
            </div>

            <div>
              <Card className="border-purple-200">
                <CardHeader>
                  <CardTitle className="font-serif-elegant text-xl text-primary">Order Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Coupon */}
                  <div className="mb-4 space-y-2">
                    <label className="text-sm text-muted-foreground">Coupon Code</label>
                    <div className="flex gap-2">
                      <Input placeholder="Enter code" value={coupon} onChange={(e) => setCoupon(e.target.value)} />
                      <Button
                        variant="outline"
                        className="border-amber-300 text-amber-700 hover:bg-amber-50"
                        onClick={() => {
                          const { discount, applied } = applyCoupon(coupon.trim(), subtotal);
                          setAppliedDiscount(discount);
                          setAppliedCode(applied?.code);
                          toast({ title: applied ? `Coupon applied: ${applied.code}` : "Invalid coupon", description: applied ? undefined : "Please check the code and try again." });
                        }}
                        disabled={isEmpty || !coupon}
                      >
                        Apply
                      </Button>
                    </div>
                    {appliedDiscount > 0 && (
                      <p className="text-xs text-green-600">Applied {appliedCode} • You save {formatPrice(appliedDiscount)}</p>
                    )}
                  </div>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="font-medium">{formatPrice(subtotal)}</span></div>
                    {appliedDiscount > 0 && (
                      <div className="flex justify-between"><span className="text-muted-foreground">Discount{appliedCode ? ` (${appliedCode})` : ""}</span><span className="font-medium text-green-700">- {formatPrice(appliedDiscount)}</span></div>
                    )}
                    <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span className="font-medium">{shipping === 0 ? "Free" : formatPrice(shipping)}</span></div>
                    <Separator />
                    <div className="flex justify-between text-base font-semibold">
                      <span>Total</span>
                      <span className="text-accent">{formatPrice(total)}</span>
                    </div>
                  </div>
                  <Button
                    className="mt-6 w-full bg-amber-500 text-white hover:bg-amber-600 transition shadow-sm hover:shadow"
                    disabled={isEmpty}
                    onClick={() => {
                      if (isEmpty) return;
                      beginCheckoutFromCart(appliedCode, appliedDiscount);
                      setCheckoutState({ total });
                      navigate("/checkout/shipping");
                    }}
                  >
                    Proceed to Checkout
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <Footer />
      </main>
    </>
  );
};

export default Cart;
