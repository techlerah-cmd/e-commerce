import { Product, allProducts as seedProducts } from "@/data/products";

export type AdminProductInput = Omit<Product, "id"> & { id?: number };
export type Coupon = {
  code: string;
  description?: string;
  discountType: "percent" | "flat";
  amount: number; // percent 0-100 or flat in INR
  active: boolean;
};
export type Order = {
  id: string;
  items: Array<{ productId: number; name: string; price: number; quantity: number; image: string }>;
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  createdAt: string;
  couponCode?: string;
  customer?: { name?: string; phone?: string; email?: string; address?: string };
};

const ADMIN_PRODUCTS_KEY = "admin_products";
const ADMIN_COUPONS_KEY = "admin_coupons";
const ADMIN_ORDERS_KEY = "admin_orders";

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

// Products
export function getAdminProducts(): Product[] {
  return read<Product[]>(ADMIN_PRODUCTS_KEY, []);
}
export function saveAdminProducts(list: Product[]) {
  write(ADMIN_PRODUCTS_KEY, list);
}
export function addAdminProduct(input: AdminProductInput): Product {
  const list = getAdminProducts();
  const nextId = Math.max(0, ...seedProducts.map(p => p.id), ...list.map(p => p.id)) + 1;
  const product: Product = { ...input, id: input.id ?? nextId } as Product;
  list.push(product);
  saveAdminProducts(list);
  return product;
}
export function getAllProductsCombined(): Product[] {
  return [...seedProducts, ...getAdminProducts()];
}

// Coupons
export function getCoupons(): Coupon[] {
  return read<Coupon[]>(ADMIN_COUPONS_KEY, []);
}
export function saveCoupons(list: Coupon[]) {
  write(ADMIN_COUPONS_KEY, list);
}
export function addCoupon(coupon: Coupon) {
  const list = getCoupons();
  const existing = list.find(c => c.code.toLowerCase() === coupon.code.toLowerCase());
  if (existing) {
    Object.assign(existing, coupon);
  } else {
    list.push(coupon);
  }
  saveCoupons(list);
}
export function applyCoupon(code: string, subtotal: number): { discount: number; applied?: Coupon } {
  const c = getCoupons().find(c => c.active && c.code.toLowerCase() === code.toLowerCase());
  if (!c) return { discount: 0 };
  const discount = c.discountType === "percent" ? Math.round((c.amount / 100) * subtotal) : Math.min(subtotal, c.amount);
  return { discount, applied: c };
}

// Orders
export function getOrders(): Order[] {
  return read<Order[]>(ADMIN_ORDERS_KEY, []);
}
export function saveOrders(list: Order[]) {
  write(ADMIN_ORDERS_KEY, list);
}
export function createOrder(order: Omit<Order, "id" | "createdAt">): Order {
  const list = getOrders();
  const full: Order = { ...order, id: crypto.randomUUID(), createdAt: new Date().toISOString() } as Order;
  list.unshift(full);
  saveOrders(list);
  return full;
}
